# Flywheel Superapp bundle (2026-07-11)

Run: python scripts/run_harness_cli.py app --port 8799
Then open http://127.0.0.1:8799/site/index.html
Zero dependencies. Route online with keys, or run offline against local weights.

155 files; see MANIFEST.sha256.
